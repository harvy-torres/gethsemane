<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'gethsemane');

/** MySQL database username */
define('DB_USER', 'parishoners');

/** MySQL database password */
define('DB_PASSWORD', 'P@ssw0rd');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('FS_METHOD', 'direct');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ':.tne>+!-BW+Orx>m|+yxx|T:%1p*O,:BV-xa}vd:HE8.V2+)dgk:-Vdi_2Q0q<L');
define('SECURE_AUTH_KEY',  'l)-m|%!YdX)^:8V^mO~Nw)V%q;G~Hy/(+!rZOQ-7E4-f4][uss>!R=&*a1cgfRkQ');
define('LOGGED_IN_KEY',    '}PO<T)l!);|(b?9>I2_/2Y#5`KYQ5%Q[Q9>2GrEO/0pIg.r>a:T_0L9kL*,Cn=o|');
define('NONCE_KEY',        '.v^Eh:K1L#N,otp7|3B7^(>W45x&~$C(ej6r<(}c^(iYs`6+f|1^1V}?hl%(+qne');
define('AUTH_SALT',        ')qTEfgibx-E+$iaQ<hN[a4Wz~93Fm0Gw]9|<--9ww[-:iml>zvf+Vm80q%T4pRR!');
define('SECURE_AUTH_SALT', '^vT7nF,k>z ]!X%GWcqpo}9vy5K>QMFJ[+.R?>+-Jn$Usz5d,(Zi,NT9R-6g/(CW');
define('LOGGED_IN_SALT',   '$@YK*pW>pu.o<BtS_?uT7g~pZ3e+, 4LoA| ckF+x7e)?V;Nm53I~%rK2tGyL8+C');
define('NONCE_SALT',       'WKyDXfjl.DRVGt~!3;~WMoFAr-=0We*^o93s,jL$085$#lUJA,MG[3?h,vR#%y-V');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
